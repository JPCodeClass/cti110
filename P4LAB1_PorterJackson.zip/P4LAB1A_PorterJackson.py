#Jaackson Porter
#4/6/2025
#P4LAB1A
#This program draws a sqaure, then a triangle inside that square

import turtle
wn = turtle.Screen()
square = turtle.Turtle()
triangle = turtle.Turtle()

for i in range(4):
    square.forward(100)
    square.left(90)

for i in range(3):
    triangle.forward(100)
    triangle.left(120)

