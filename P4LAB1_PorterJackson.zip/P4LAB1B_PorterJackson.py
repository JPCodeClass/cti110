#Jackson Porter
#4/6/2025
#P4LAB1B
#This program loads a black background with an orange turtle to draw the initials JP

import turtle
wn = turtle.Screen()
wn.bgcolor('black')
initial = turtle.Turtle()
initial.color('orange')
initial.pensize(13)

for i in range(1):
    initial.forward(100)
    initial.left(180)
    initial.forward(50)
    initial.left(90)
    initial.forward(100)
    initial.circle(-25, 200)
    initial.penup()
    initial.goto(120, 0)
    initial.pendown()
    initial.right(160)
    initial.forward(120)
    initial.left(180)
    initial.forward(120)
    initial.right(90)
    initial.circle(-35, 180)

wn.mainloop()
    
